package com.keely.volalarm;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class KeyService extends AccessibilityService {
    private final Handler handler = new Handler();
    private Runnable pending, stopper;
    private Ringtone ringtone;
    private SharedPreferences prefs;
    private boolean pausedByUs = false;
    private PowerManager.WakeLock wl;
    private final SharedPreferences.OnSharedPreferenceChangeListener listener =
        new SharedPreferences.OnSharedPreferenceChangeListener() {
            public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                if ("on".equals(key) && !sp.getBoolean("on", true)) { stopAll(); resumeMusic(); }
            }
        };

    @Override
    protected void onServiceConnected() {
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        prefs.registerOnSharedPreferenceChangeListener(listener);
        Notif.running = true;
        Notif.show(this);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(listener);
        Notif.running = false;
        Notif.hide(this);
        stopAll();
        resumeMusic();
        return super.onUnbind(intent);
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (!Notif.isOn(this)) return false;
        int k = event.getKeyCode();
        boolean up = k == KeyEvent.KEYCODE_VOLUME_UP, down = k == KeyEvent.KEYCODE_VOLUME_DOWN;
        if (!up && !down) return false;
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            stopAll();
            resumeMusic();
            pending = start(up ? prefs.getInt("sec1", 60) : prefs.getInt("sec2", 30));
        }
        return true;
    }

    private Runnable start(int seconds) {
        Runnable r = new Runnable() { public void run() { ring(); } };
        hold(seconds * 1000L + 15000L);
        handler.postDelayed(r, seconds * 1000L);
        buzz(60);
        return r;
    }

    private void stopAll() {
        if (pending != null) handler.removeCallbacks(pending);
        if (stopper != null) handler.removeCallbacks(stopper);
        if (ringtone != null && ringtone.isPlaying()) ringtone.stop();
        release();
    }

    private void ring() {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am.isMusicActive()) {
            media(KeyEvent.KEYCODE_MEDIA_PAUSE);
            pausedByUs = true;
            pending = new Runnable() { public void run() { playSound(); } };
            handler.postDelayed(pending, 400);
        } else {
            playSound();
        }
    }

    private void playSound() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        String s = prefs.getString("sound", null);
        try {
            if (s != null) u = Uri.parse(s);
            ringtone = RingtoneManager.getRingtone(this, u);
            ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            ringtone.play();
        } catch (Exception ex) {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            ringtone.play();
        }
        buzz(800);
        stopper = new Runnable() { public void run() { if (ringtone != null) ringtone.stop(); release(); } };
        handler.postDelayed(stopper, 10000);
    }

    private void resumeMusic() {
        if (pausedByUs) {
            pausedByUs = false;
            media(KeyEvent.KEYCODE_MEDIA_PLAY);
        }
    }

    private void media(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private void hold(long ms) {
        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "volalarm:timer");
            wl.setReferenceCounted(false);
        }
        wl.acquire(ms);
    }

    private void release() {
        if (wl != null && wl.isHeld()) wl.release();
    }

    private void buzz(long ms) {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(ms);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() { stopAll(); }
}
