package com.keely.volalarm;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    EditText e1, e2;
    Switch sw;
    TextView soundName;
    CompoundButton.OnCheckedChangeListener swListener;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        e1 = (EditText) findViewById(R.id.sec1);
        e2 = (EditText) findViewById(R.id.sec2);
        sw = (Switch) findViewById(R.id.power);
        soundName = (TextView) findViewById(R.id.soundName);
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        e1.setText(String.valueOf(p.getInt("sec1", 60)));
        e2.setText(String.valueOf(p.getInt("sec2", 30)));
        swListener = new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean on) {
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("on", on).apply();
                if (Notif.running) Notif.show(MainActivity.this);
            }
        };
        showSoundName();
    }

    @Override
    protected void onResume() {
        super.onResume();
        sw.setOnCheckedChangeListener(null);
        sw.setChecked(Notif.isOn(this));
        sw.setOnCheckedChangeListener(swListener);
    }

    public void save(View v) {
        int a = parse(e1.getText().toString(), 60);
        int c = parse(e2.getText().toString(), 30);
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putInt("sec1", a).putInt("sec2", c).apply();
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
    }

    public void enable(View v) {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    public void battery(View v) {
        if (Build.VERSION.SDK_INT >= 23) {
            startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                Uri.parse("package:" + getPackageName())));
        }
    }

    public void chooseSound(View v) {
        if (Build.VERSION.SDK_INT >= 23
            && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 2);
            return;
        }
        openPicker();
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        openPicker();
    }

    private void openPicker() {
        Intent i = new Intent(RingtoneManager.ACTION_RINGTONE_PICKER);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TYPE,
            RingtoneManager.TYPE_ALARM | RingtoneManager.TYPE_RINGTONE | RingtoneManager.TYPE_NOTIFICATION);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, true);
        i.putExtra(RingtoneManager.EXTRA_RINGTONE_TITLE, "Choose alarm sound");
        String s = getSharedPreferences("cfg", MODE_PRIVATE).getString("sound", null);
        if (s != null) i.putExtra(RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(s));
        startActivityForResult(i, 1);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == 1 && res == RESULT_OK && data != null) {
            Uri u = data.getParcelableExtra(RingtoneManager.EXTRA_RINGTONE_PICKED_URI);
            SharedPreferences.Editor ed = getSharedPreferences("cfg", MODE_PRIVATE).edit();
            if (u == null) ed.remove("sound"); else ed.putString("sound", u.toString());
            ed.apply();
            showSoundName();
        }
    }

    private void showSoundName() {
        String s = getSharedPreferences("cfg", MODE_PRIVATE).getString("sound", null);
        String name = "default";
        if (s != null) {
            try {
                Ringtone r = RingtoneManager.getRingtone(this, Uri.parse(s));
                if (r != null) name = r.getTitle(this);
            } catch (Exception ex) { }
        }
        soundName.setText("Sound: " + name);
    }

    private int parse(String s, int def) {
        try { int n = Integer.parseInt(s.trim()); return n > 0 ? n : def; }
        catch (Exception ex) { return def; }
    }
}
