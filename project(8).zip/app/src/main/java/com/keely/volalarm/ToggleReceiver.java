package com.keely.volalarm;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class ToggleReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        boolean now = Notif.isOn(c);
        c.getSharedPreferences("cfg", Context.MODE_PRIVATE).edit().putBoolean("on", !now).apply();
        Notif.show(c);
    }
}
