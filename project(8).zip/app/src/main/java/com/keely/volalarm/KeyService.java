package com.keely.volalarm;

import android.accessibilityservice.AccessibilityService;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.media.VolumeProvider;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.net.Uri;
import android.os.Handler;
import android.os.PowerManager;
import android.os.SystemClock;
import android.os.Vibrator;
import android.view.KeyEvent;
import android.view.accessibility.AccessibilityEvent;

public class KeyService extends AccessibilityService {
    private final Handler handler = new Handler();
    private Runnable pending, stopper;
    private Ringtone ringtone;
    private SharedPreferences prefs;
    private boolean pausedByUs = false;
    private PowerManager.WakeLock wl;
    private MediaSession session;
    private long lastTrigger = 0;
    private BroadcastReceiver screenReceiver;
    private AudioTrack silent;
    private Thread silentThread;
    private volatile boolean silentRun = false;

    private final SharedPreferences.OnSharedPreferenceChangeListener listener =
        new SharedPreferences.OnSharedPreferenceChangeListener() {
            public void onSharedPreferenceChanged(SharedPreferences sp, String key) {
                if ("on".equals(key) && !sp.getBoolean("on", true)) {
                    stopAll();
                    resumeMusic();
                    disableSession();
                }
            }
        };

    @Override
    protected void onServiceConnected() {
        prefs = getSharedPreferences("cfg", MODE_PRIVATE);
        prefs.registerOnSharedPreferenceChangeListener(listener);
        screenReceiver = new BroadcastReceiver() {
            public void onReceive(Context c, Intent i) {
                if (Intent.ACTION_SCREEN_OFF.equals(i.getAction())) {
                    if (Notif.isOn(c)) enableSession();
                } else {
                    disableSession();
                }
            }
        };
        IntentFilter f = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_SCREEN_ON);
        registerReceiver(screenReceiver, f);
        Notif.running = true;
        Notif.show(this);
    }

    @Override
    public boolean onUnbind(Intent intent) {
        if (prefs != null) prefs.unregisterOnSharedPreferenceChangeListener(listener);
        if (screenReceiver != null) {
            try { unregisterReceiver(screenReceiver); } catch (Exception ex) { }
            screenReceiver = null;
        }
        disableSession();
        Notif.running = false;
        Notif.hide(this);
        stopAll();
        resumeMusic();
        return super.onUnbind(intent);
    }

    private void enableSession() {
        if (session != null) return;
        prefs.edit().putInt("offStarts", prefs.getInt("offStarts", 0) + 1).apply();
        session = new MediaSession(this, "VolumeAlarm");
        session.setFlags(MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() { });
        session.setPlaybackToRemote(new VolumeProvider(VolumeProvider.VOLUME_CONTROL_RELATIVE, 100, 50) {
            @Override
            public void onAdjustVolume(int direction) {
                prefs.edit().putInt("offPresses", prefs.getInt("offPresses", 0) + 1).apply();
                long now = SystemClock.uptimeMillis();
                if (now - lastTrigger < 500) return;
                lastTrigger = now;
                if (direction > 0) trigger(true);
                else if (direction < 0) trigger(false);
            }
        });
        session.setPlaybackState(new PlaybackState.Builder()
            .setState(PlaybackState.STATE_PLAYING, 0, 1f).build());
        session.setActive(true);
        silentOn();
    }

    private void disableSession() {
        silentOff();
        if (session == null) return;
        try { session.setActive(false); session.release(); } catch (Exception ex) { }
        session = null;
    }

    @Override
    protected boolean onKeyEvent(KeyEvent event) {
        if (!Notif.isOn(this)) return false;
        int k = event.getKeyCode();
        boolean up = k == KeyEvent.KEYCODE_VOLUME_UP, down = k == KeyEvent.KEYCODE_VOLUME_DOWN;
        if (!up && !down) return false;
        if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {
            trigger(up);
        }
        return true;
    }

    private void trigger(boolean up) {
        if (!Notif.isOn(this)) return;
        stopAll();
        resumeMusic();
        pending = start(up ? prefs.getInt("sec1", 60) : prefs.getInt("sec2", 30));
    }

    private Runnable start(int seconds) {
        Runnable r = new Runnable() { public void run() { ring(); } };
        hold(seconds * 1000L + 15000L);
        handler.postDelayed(r, seconds * 1000L);
        buzz(60);
        return r;
    }

    private void stopAll() {
        if (pending != null) handler.removeCallbacks(pending);
        if (stopper != null) handler.removeCallbacks(stopper);
        if (ringtone != null && ringtone.isPlaying()) ringtone.stop();
        release();
    }

    private void ring() {
        final boolean hadSilent = silentRun;
        if (hadSilent) silentOff();
        pending = new Runnable() { public void run() { afterCheck(hadSilent); } };
        handler.postDelayed(pending, hadSilent ? 250 : 0);
    }

    private void afterCheck(boolean hadSilent) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        boolean music = am.isMusicActive();
        if (hadSilent && session != null) silentOn();
        if (music) {
            media(KeyEvent.KEYCODE_MEDIA_PAUSE);
            pausedByUs = true;
            pending = new Runnable() { public void run() { playSound(); } };
            handler.postDelayed(pending, 400);
        } else {
            playSound();
        }
    }

    private void silentOn() {
        if (silentRun) return;
        try {
            final int min = AudioTrack.getMinBufferSize(8000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT);
            final AudioTrack t = new AudioTrack(AudioManager.STREAM_MUSIC, 8000, AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT, min, AudioTrack.MODE_STREAM);
            t.play();
            silent = t;
            silentRun = true;
            silentThread = new Thread() {
                public void run() {
                    byte[] zeros = new byte[min];
                    while (silentRun) {
                        try { t.write(zeros, 0, zeros.length); } catch (Exception ex) { break; }
                    }
                }
            };
            silentThread.start();
        } catch (Exception ex) {
            silentRun = false;
        }
    }

    private void silentOff() {
        silentRun = false;
        try { if (silentThread != null) silentThread.join(300); } catch (Exception ex) { }
        silentThread = null;
        if (silent != null) {
            try { silent.pause(); silent.flush(); silent.release(); } catch (Exception ex) { }
            silent = null;
        }
    }

    private void playSound() {
        Uri u = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
        String s = prefs.getString("sound", null);
        try {
            if (s != null) u = Uri.parse(s);
            ringtone = RingtoneManager.getRingtone(this, u);
            ringtone.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM).build());
            ringtone.play();
        } catch (Exception ex) {
            ringtone = RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM));
            ringtone.play();
        }
        buzz(800);
        stopper = new Runnable() { public void run() { if (ringtone != null) ringtone.stop(); release(); } };
        handler.postDelayed(stopper, 10000);
    }

    private void resumeMusic() {
        if (pausedByUs) {
            pausedByUs = false;
            media(KeyEvent.KEYCODE_MEDIA_PLAY);
        }
    }

    private void media(int code) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, code));
        am.dispatchMediaKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, code));
    }

    private void hold(long ms) {
        if (wl == null) {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            wl = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "volalarm:timer");
            wl.setReferenceCounted(false);
        }
        wl.acquire(ms);
    }

    private void release() {
        if (wl != null && wl.isHeld()) wl.release();
    }

    private void buzz(long ms) {
        Vibrator v = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        if (v != null) v.vibrate(ms);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() { stopAll(); }
}
