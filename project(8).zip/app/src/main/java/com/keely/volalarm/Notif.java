package com.keely.volalarm;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

public class Notif {
    static final int ID = 1;
    static final String CH = "volalarm";
    static boolean running = false;

    static boolean isOn(Context c) {
        return c.getSharedPreferences("cfg", Context.MODE_PRIVATE).getBoolean("on", true);
    }

    static void show(Context c) {
        boolean on = isOn(c);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Volume Alarm", NotificationManager.IMPORTANCE_LOW));
            b = new Notification.Builder(c, CH);
        } else {
            b = new Notification.Builder(c);
        }
        int fl = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        PendingIntent open = PendingIntent.getActivity(c, 0, new Intent(c, MainActivity.class), fl);
        PendingIntent toggle = PendingIntent.getBroadcast(c, 1, new Intent(c, ToggleReceiver.class), fl);
        b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
         .setContentTitle("Volume Alarm is " + (on ? "ON" : "OFF"))
         .setContentText(on ? "Volume buttons start your alarms" : "Volume buttons work normally")
         .setContentIntent(open)
         .setOngoing(true)
         .addAction(0, on ? "Turn off" : "Turn on", toggle);
        nm.notify(ID, b.build());
    }

    static void hide(Context c) {
        ((NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(ID);
    }
}
