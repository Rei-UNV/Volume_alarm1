package com.keely.volalarm;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

public class MainActivity extends Activity {
    EditText e1, e2;
    Switch sw;
    CompoundButton.OnCheckedChangeListener swListener;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        e1 = (EditText) findViewById(R.id.sec1);
        e2 = (EditText) findViewById(R.id.sec2);
        sw = (Switch) findViewById(R.id.power);
        SharedPreferences p = getSharedPreferences("cfg", MODE_PRIVATE);
        e1.setText(String.valueOf(p.getInt("sec1", 60)));
        e2.setText(String.valueOf(p.getInt("sec2", 30)));
        swListener = new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton v, boolean on) {
                getSharedPreferences("cfg", MODE_PRIVATE).edit().putBoolean("on", on).apply();
                if (Notif.running) Notif.show(MainActivity.this);
            }
        };
    }

    @Override
    protected void onResume() {
        super.onResume();
        sw.setOnCheckedChangeListener(null);
        sw.setChecked(Notif.isOn(this));
        sw.setOnCheckedChangeListener(swListener);
    }

    public void save(View v) {
        int a = parse(e1.getText().toString(), 60);
        int c = parse(e2.getText().toString(), 30);
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putInt("sec1", a).putInt("sec2", c).apply();
        Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show();
    }

    public void enable(View v) {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private int parse(String s, int def) {
        try { int n = Integer.parseInt(s.trim()); return n > 0 ? n : def; }
        catch (Exception ex) { return def; }
    }
}
